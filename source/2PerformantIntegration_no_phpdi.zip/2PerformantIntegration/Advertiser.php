<?php
/**
 * Created by PhpStorm.
 * User: cosmi
 * Date: 13-Oct-18
 * Time: 9:25 AM
 */

namespace App\Models;


class Advertiser
{
    public $id;
    public $defaultCommission;
    public $url;
    public $description;
}