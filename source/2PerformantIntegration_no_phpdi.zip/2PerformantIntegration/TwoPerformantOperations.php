<?php
/**
 * Created by PhpStorm.
 * User: cosmi
 * Date: 08-Oct-18
 * Time: 10:13 PM
 */

namespace App\Integration;
require 'vendor/autoload.php';
require 'Config.php';
require 'Utils.php';
require 'Advertiser.php';
require 'ConfigurationException.php';

use Monolog\Handler\StreamHandler;
use TPerformant\API\HTTP\Affiliate;
use TPerformant\API\Exception;
use App\Config;
use App\Models;
use Monolog\Logger;


class TwoPerformantOperations
{

    private $config;
    private $log;

    public function __construct(Config\Config $_config, Logger $logger)
    {
        $this->config = $_config;
        $this->log = $logger;
    }

    protected function initAffiliate()
    {
        $this->log = new Logger(TwoPerformantOperations::class);
        $this->log->pushHandler(new StreamHandler("app.log", Logger::DEBUG));
        $affiliate = null;

        try
        {
            $affiliate = new Affiliate($this->config->getEmail(), $this->config->getPassword());
        }
        catch (Exception\APIException $ex)
        {
            $this->log->err($ex->getMessage());
        }
        return $affiliate;
    }

    /**
     * @author Popescu Cosmin Ionut
     * @email cosmin.popescu93@gmail.com
     */
    public function getAdvertisers()
    {

        $advertisers = [];
        try
        {
            $apiResponse = self::initAffiliate()->getPrograms();

            foreach ($apiResponse as $response)
            {
                $advertiser = new Models\Advertiser();

                $advertiser->id = $response->getId();
                $advertiser->defaultCommission = $response->getDefaultSaleCommissionRate();
                $advertiser->url = self::convertToAffiliateLink($response->getMainUrl(), $response->getUniqueCode());
                $advertiser->description = $response->getDescription();

                $advertisers[] = $advertiser;
            }

            $this->log->info("", ["got" => count($advertisers)]);
            return $advertisers;
        }
        catch (\App\Exception\ConfigurationException $configurationException)
        {
            $this->log->err($configurationException->getMessage());
        }
    }

    private function convertToAffiliateLink($link, $program)
    {
        return $this->initAffiliate()->getQuicklink($link, $program);
    }
}